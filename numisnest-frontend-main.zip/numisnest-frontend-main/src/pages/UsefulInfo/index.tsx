import { Box } from '@mui/material'
import React, { useEffect, useState } from 'react'
import { axiosPublic } from 'src/axios/axios'
import InfromationCard from 'src/components/AdminComponents/AdminCards/infromationCard'
import SelectComp from 'src/components/Select/SelectComp'
import VisitorLayout from 'src/components/layouts/VisitorLayout'
import { InformationType } from 'src/utilities/types'

const UsefulInfromationPage = () => {
  const [informationList ,setInformationList]= useState<InformationType[]>([])
  const [country ,setCountry]= useState<string>("")
  const [availableCountires,setAvailableCountires]= useState([])
  useEffect(()=>{
    const getusefulInformation = async()=>{
      try {
        const response = await axiosPublic.get(`duo/general/info?country=${country}`);
        console.log(response)
        const {data}= response.data
        setInformationList(data)
      } catch (error) {
        
      }
    }
    
    getusefulInformation()
    
  },[country])
 useEffect(()=>{
  const getinfoCountry = async () => {
    try {
      const response = await axiosPublic.get(`duo/general/info/countries`);
      const { data } = response.data;
      console.log(data);
      setAvailableCountires(data);
    } catch (error) {}
  };
  getinfoCountry();
 },[])
  return (
    <VisitorLayout>
      <Box>
        <SelectComp
          menuItems={[...availableCountires]}
          value={country}
          selectLabel="showing Info for"
          handleChange={(value) => setCountry(value)}
        />
      </Box>
      <Box
        sx={{
          height: "100%",
          mt: "1.5rem",
          display: "grid",
          gridTemplateColumns:{xs:"1fr",sm:"1fr",md:" repeat(2, 1fr)"},
          columnGap: "1rem",
          rowGap: "2rem",
        }}
      >
        {informationList?.map((infromation) => (
          <Box>
            <InfromationCard
              title={infromation.title}
              description={infromation.description}
              key={infromation._id}
              id={infromation._id}
              cardtype='public'
            />
          </Box>
        ))}
      </Box>
    </VisitorLayout>
  );
}

export default UsefulInfromationPage