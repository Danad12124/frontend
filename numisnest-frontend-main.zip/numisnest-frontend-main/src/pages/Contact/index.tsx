import { Box, Typography, useMediaQuery } from '@mui/material'
import ContactusForm from 'src/components/forms/contactus-form';
import VisitorLayout from 'src/components/layouts/VisitorLayout'
const ContactusPage = () => {
  const isNotMobileScreens = useMediaQuery("(min-width:600px)");
  return (
    <VisitorLayout>
      <Box>
        <Typography
          variant={isNotMobileScreens ? "h1" : "h2"}
          sx={{ fontWeight: "bold", textAlign: "center" }}
        >
          Contact us
        </Typography>
        <Typography variant='h3' sx={{textAlign: "center",mt:"1rem" }}>
          Any questions? Suggestions? We would love to hear!
        </Typography>
      </Box>
      <Box
        sx={{
          px: { xs: "0.5rem", sm: "2rem", md: "4rem", lg: "9.5rem" },
          mt: "2rem",
        }}
      >
        <ContactusForm />
      </Box>
    </VisitorLayout>
  );
}

export default ContactusPage