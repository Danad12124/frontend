import { Box, Typography, useMediaQuery } from "@mui/material"
import Homeheader from "../headers/Homeheader"
import { ReactNode } from "react"
import radialbg from "src/assets/Image/radalbg.png"
import Image from "../Image"
import { color } from "chart.js/helpers"
interface Props{
  children:ReactNode
}
const VisitorLayout = ({children}:Props) => {
  const isNotMobileScreens = useMediaQuery("(min-width:900px)");
  
  return (
    <Box sx={{ position: "relative", zIndex: 2 }}>
      <Homeheader />
      <Typography
        variant={isNotMobileScreens ? "h3" : "body1"}
        sx={{ color: "red", textAlign: "center", fontFamily: '"Lemon", serif' }}
      >
        Site under construction for details contact{" "}
        <a href="mailto:yishaicohen93@gmail.com" style={{ color: "red" }}>
          yishaicohen93@gmail.com
        </a>
      </Typography>
      <Box
        sx={{
          px: {
            xs: "0.5rem",
            sm: "1.8rem",
            md: "2.8rem",
            lg: "3.8",
            xl: "4.6rem",
          },
        }}
      >
        {children}
      </Box>
      {isNotMobileScreens && (
        <Image
          src={radialbg}
          alt="bg"
          sx={{
            width: "30rem",
            height: "25rem",
            zIndex: -1,
            position: "absolute",
            top: 400,
          }}
        />
      )}
    </Box>
  );
}

export default VisitorLayout