import { Box, IconButton, useMediaQuery } from "@mui/material";
import  {FlashAuto, ZoomOutMapOutlined} from "@mui/icons-material"
import money from "src/assets/Image/money.png";
import nora from "src/assets/Image/nora.jpg";
import jenny from "src/assets/Image/jenny.jpg";
import Image from "../Image";
import video from "src/assets/Image/video.mp4";
import { BorderClear } from "@mui/icons-material";
import SimpleBar from "simplebar-react";
import { Fragment, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import videotag from "src/assets/Image/videotag.png";
import ImageZoom from "../Modal/image-zoom";
import { Photo } from "src/utilities/types";
interface Props {
  arr:any[]
}
const Itemdisplay2 = ({arr }:Props) => {
  console.log(arr)
  const arrs = [money, money, nora, jenny, nora, video];
  const [activepic, setActivepicture] = useState<number>(0);
  const isNotMobileScreens = useMediaQuery("(min-width:600px)");
  const isVideo = (path: string) => {
   
    return path?.endsWith(".mp4") || path?.endsWith(".webm")
  };
  const [Imagezoom,setImageZoom]= useState<boolean>(false)
  
  return (
    <Box component={"section"}>
      {Imagezoom && (
        <ImageZoom
          contentWidth="80%"
          closeModal={() => setImageZoom(false)}
          filePath={arr[activepic].secure_url}
        />
      )}
      <Box
        sx={{
          display: "flex",
          flexDirection: isNotMobileScreens ? "row" : "column-reverse",
          alignItems: isNotMobileScreens ? "" : "center",
          transform: { xs: "scale(0.62)", sm: "scale(0.65)", md: "scale(1)" },
          transformOrigin: "top",
        }}
      >
        <SimpleBar
          style={{
            height: isNotMobileScreens ? "30rem" : "8rem",
            width: isNotMobileScreens ? "8rem" : "30rem",
          }}
        >
          <Box
            sx={{
              display: "flex",
              flexDirection: isNotMobileScreens ? "column" : "row",
              maxHeight: "10rem",
              maxWidth: "auto",
              gap: "1.5rem",
            }}
          >
            {arr?.map((item: Photo, index) => (
              <Box
                key={index}
                component={"div"}
                onClick={() => setActivepicture(index)}
                sx={{
                  borderRadius: "8px",
                  marginRight: "0.5rem",
                  objectFit: "cover",
                  height: "8rem",
                  width: "8rem",
                }}
              >
                {item?.secure_url !== "" && (
                  <Fragment>
                    {isVideo(item?.secure_url) ? (
                      <Box
                        sx={{
                          width: "100%",
                          height: "100%",
                          objectFit: "cover",
                          position: "relative",
                        }}
                      >
                        <img
                          src={videotag}
                          style={{
                            position: "absolute",
                            width: "4rem",
                            top: "50%",
                            left: "50%",
                            transform: "translate(-50%, -50%)",
                          }}
                        />
                        <video
                          src={item?.secure_url}
                          style={{
                            width: "7.78rem",
                            height: "100%",
                            objectFit: "cover",
                            borderRadius: "8px",
                          }}
                        />
                      </Box>
                    ) : (
                      <Box
                        sx={{
                          width: "7.78rem",
                          height: "8rem",
                          backgroundImage: `url(${item?.secure_url})`,
                          backgroundSize: "cover",
                          backgroundRepeat: "no-repeat",
                          borderRadius: "0.5rem",
                          backgroundPosition: "center",
                        }}
                        position={"relative"}
                      >
                        {/* <Image
                      src={item}
                      alt={`image-${index}`}
                      style={{
                        objectFit: "cover",
                        width: "auto",
                        height: "8rem",
                        display: "block",
                        maxWidth: "100%",
                        maxHeight: "100%",
                      }}
                    /> */}
                      </Box>
                    )}
                  </Fragment>
                )}
              </Box>
            ))}
          </Box>
        </SimpleBar>

        <Box
          sx={{
            width: "38rem",
            height: "30rem",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            objectFit: "contain",
            ml: isNotMobileScreens ? "3rem" : "",
            mb: "1rem",
            position: "relative",
          }}
        >
          {!isVideo(arr?.[activepic]?.secure_url) && (
            <IconButton
              sx={{ position: "absolute", bottom: 0, right: 0 }}
              onClick={() => setImageZoom(true)}
            >
              <ZoomOutMapOutlined sx={{ fontSize: "3rem", color: "#0047AB" }} />
            </IconButton>
          )}

          <AnimatePresence>
            {isVideo(arr[activepic]?.secure_url) ? (
              <motion.video
                key={activepic}
                src={arr[activepic]?.secure_url}
                style={{
                  objectFit: "contain",
                  width: "auto",
                  height: "35rem",
                  display: "block",
                  maxWidth: "100%",
                  maxHeight: "100%",
                }}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ duration: 0.4 }}
                autoPlay
                loop
                controls
              />
            ) : (
              <motion.img
                key={activepic}
                src={arr[activepic]?.secure_url}
                alt={`image-${activepic}`}
                style={{
                  objectFit: "contain",
                  width: "auto",
                  height: "35rem",
                  display: "block",
                  maxWidth: "100%",
                  maxHeight: "100%",
                }}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ duration: 0.4 }}
              />
            )}
          </AnimatePresence>
        </Box>
      </Box>
    </Box>
  );
};

export default Itemdisplay2;
