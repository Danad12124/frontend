import { Box, Typography, useMediaQuery } from "@mui/material";
import { motion } from "framer-motion";
import Display from "./display";
import ItemDesc from "./itemdesc";
import SellerAbout from "./sellerAbout";
import { SingleItemType } from "src/utilities/types";
import { Photo } from "@mui/icons-material";
import SimilarItems from "./similarItems";
import Itemdisplay2 from "./itemdisplay2";
import { textFromat } from "src/utilities/constants/helpers";

const ItemDisplay = ({data}:{data?:SingleItemType|null}) => {

  const isNotMobileScreens = useMediaQuery("(min-width:600px)");
  return (
    <Box>
      <Typography
        sx={{
          fontSize: { xs: "2rem", sm: "2.5rem", md: "3.2rem" },
          fontWeight: 700,
          textAlign: { xs: "center", sm: "center", md: "start" },
          mt: { xs: "1rem", sm: "3rem", lg: "4rem" },
        }}
      >
        Item Description
      </Typography>
      <Typography
        sx={{
          fontSize: { xs: "1rem", sm: "1.5rem", md: "1.8rem" },
          fontWeight: 700,
          textAlign: { xs: "center", sm: "center", md: "start" },
          textDecoration: "underline",
          mt: { xs: "0.8rem", sm: "0.8rem", lg: "0.8rem" },
          mb: "1rem",
        }}
      >
        Item ID {data?._id.slice(0, 10)}
      </Typography>
      <Box
        sx={{
          display: "flex",

          alignItems: "center",
          flexDirection: { xs: "column", sm: "row" },
        }}
      >
        <Box sx={isNotMobileScreens ? {} : { width: "100%" }}>
          <Itemdisplay2
            arr={data?._id ?[...data.photos, data?.video] :[]}
          />
          {/* <Display
            arry={[data?.photo1, data?.photo2, data?.photo3, data?.video]}
          /> */}
        </Box>
        <Box
          sx={{
            marginLeft: "1%",
            position: "relative",
            padding: "1.5rem",
            mt: { xs: "-10.8rem", sm: "-10rem", md: "0rem" },
          }}
        >
          <Typography
            sx={{
              fontSize: "2.5rem",
              fontWeight: 700,

              "&::after": isNotMobileScreens
                ? {
                    content: "''",
                    position: "absolute",
                    bottom: 150,
                    left: "50%",
                    transform: "translateX(-50%)",
                    width: "87%",

                    borderBottom: "5px solid black",
                  }
                : {},
            }}
          >
            {textFromat(data?.name)}
          </Typography>

          <Box sx={{ mt: { xs: "1rem", sm: "2rem", md: "4rem" } }}>
            <Typography
              sx={{
                padding: "1rem",
                bgcolor: "white",

                fontSize: "2rem",
                color: "#0047AB",
              }}
            >
              Price :{" "}
              <Typography
                component={"span"}
                sx={{ fontSize: "2.5rem", fontWeight: 700, ml: "0.5rem" }}
              >
                {`${data?.convertedPrice.toFixed()}${data?.convertedCurrency.toUpperCase()}`}
              </Typography>
            </Typography>
          </Box>
        </Box>
      </Box>

      <ItemDesc
        description={data?.description}
        deliveryOptions={data?.seller_info[0].delivery_option}
        countryCode={data?.seller_info[0].country_code}
        mobile={data?.seller_info[0].mobile}
      />
      <SellerAbout data={data?.seller_info?.[0]} />

      <SimilarItems data={data?.other_seller_items} />
    </Box>
  );
};

export default ItemDisplay;
