import { Box, Paper, Typography, useMediaQuery } from "@mui/material";
import { ItemType, SellerItemType } from "src/utilities/types";
import ItemsCard from "../cards/ItemsCard";
import { defaultItems } from "src/utilities/constants";
interface Props {
  data?:Partial <ItemType>[]
}
const SimilarItems = ({data}:Props) => {
   const isNotMobileScreens = useMediaQuery("(min-width:500px)");
  return (
    <Box sx={{ mt: "4rem" }}>
      <Typography
        component={"header"}
        sx={{ fontSize: "3rem", fontWeight: 700 }}
      >
        {data?.[0]
          ? `Similar items`
          : `Similar items from ${data?.[0]?.seller_info?.[0].first_name}`}
      </Typography>
      <Paper sx={{pt:"1rem"}}>
        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: {
              xs: "repeat(3, 1fr)",
              sm: "repeat(3, 1fr)",
              md: "repeat(4, 1fr)",
              lg: "repeat(6, 1fr)",
              xl: "repeat(6, 1fr)",
            },
            columnGap: { xs: "0.5rem", lg: "0.9rem", xl: "2rem" },
            rowGap: "2rem",
            transform: {
              xs: "scale(0.97)",
              sm: "",
              md: "",
              lg: "scale(0.99)",
            },
            justifyItems: "center",
            transformOrigin: "top ",
            mt: "2rem",
            
          }}
        >
          {data?.slice(0, 6)?.map((item: Partial<ItemType>, index: number) => (
            <ItemsCard
              key={index}
              url={item.photos?.[0]?.secure_url}
              currency={item.currency}
              selling={item.description}
              createdAt={item.updatedAt}
              amount={item.price}
              height="15.5rem"
              xsheight="12.5rem"
              bgColor="#F4F4F6"
              id={item._id}
            />
          ))}
        </Box>
      </Paper>
    </Box>
  );
};

export default SimilarItems;
