import {
  Box,
  Button,
  IconButton,
  Skeleton,
  Typography,
  useMediaQuery,
} from "@mui/material";
import "/node_modules/flag-icons/css/flag-icons.min.css";
import dayjs from "dayjs";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import EditItemsModal from "../Modal/edit-ItemsModal";
import useAxiosPrivate from "src/hooks/useAxiosPrivate";
import { textFromat } from "src/utilities/constants/helpers";
import pin from "src/assets/Image/Pin.svg";
import _ from "lodash";
import Image from "../Image";
import { toast } from "react-toastify";
export type CardType = "Private" | "public";
interface Props {
  flag?: string;
  url?: string;
  firstName?: string;
  lastName?: string;
  selling?: string;
  createdAt?: string;
  amount?: number;
  bgColor?: string;
  isFetching?: boolean;
  currency?: string;
  height?: string;
  xsheight?: string;
  id?: string;
  cardtype?: CardType;
  openModal?: () => void;
  setItemId?: (value: string | undefined) => void;
  selected?: boolean;
  remCollection?: () => void;
  featured?: boolean;
  addFeatured?: boolean;
  setRefresh?: (val: any) => void;
  openDeleteModal?:()=>void
}

const ItemsCard = ({
  flag,
  url,
  firstName,
  lastName,
  selling,
  createdAt,
  amount,
  bgColor,
  isFetching,
  currency,
  height,
  xsheight,
  id,
  selected,
  cardtype = "public",
  featured,
  addFeatured,
  setRefresh,
  openModal,
  setItemId,
  remCollection,
  openDeleteModal
}: Props) => {

  const navigate = useNavigate();
  const axiosPrivate = useAxiosPrivate();
  const isNotMobileScreens = useMediaQuery("(min-width:600px)");
  return (
    <Box>
      <div
        onClick={() => (id ? navigate(isFetching ? "" : `/item/${id}`) : "")}
      >
        <Box
          sx={{
            backgroundColor: bgColor ? bgColor : "white",
            width: {
              xs: "7.6rem",
              sm: "12rem",
              md: "12rem",
              lg: "12rem",
              xl: "12.5rem",
            },
            height: {
              xs: height ? xsheight : "13.5rem",
              sm: height ? height : "17.5rem",
              md: height ? height : "17.5rem",
              lg: height ? height : "17.5rem",
              xl: height ? height : "17.5rem",
            },
            border: selected ? "2px solid #0047AB" : null,
            pb: "1rem",
            display: "flex",
            flexDirection: "column",
            position: "relative",
            borderRadius: "0.6rem",

            transition: "all 0.3s ease-in-out allow-discrete",
            "&:hover": {
              boxShadow: " 3px 5px 10px 0.7px rgba(0, 0, 0, .2)",
              cursor: "pointer",
            },
          }}
        >
          {featured && (
            <IconButton
              sx={{ position: "absolute", top: -10, left: -10 }}
              onClick={async (e) => {
                e.stopPropagation();
                const response = await axiosPrivate.delete(
                  `seller/featured/rem/${id}`
                );
                typeof setRefresh !== "undefined" &&
                  setRefresh((prev: boolean) => !prev);
              }}
            >
              <Image
                src={pin}
                alt="pin"
                sx={{
                  width: "2.5rem",
                }}
              />
            </IconButton>
          )}
          {addFeatured && (
            <Button
              sx={{
                position: "absolute",
                top: 20,
                left: 13,
                display: "inline-flex",
                backgroundColor: "#0047AB",
                color: "#F9FAFA",
                fontSize: "0.6rem",
              }}
              onClick={async (e) => {
                e.stopPropagation();
                try {
                  const response = await axiosPrivate.put(
                    "seller/featured/add",
                    {
                      items_id: [id],
                    }
                  );
                  console.log(response);
                  typeof setRefresh !== "undefined" &&
                    setRefresh((prev: boolean) => !prev);
                  toast("item added to festured", {
                    position: "top-right",
                    autoClose: 1000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    isLoading: false,
                    type: "success",
                    theme: "light",
                    style: {},
                  });
                } catch (error: any) {
                  toast(`${error.response.data.message.split(":")[1]}`, {
                    position: "top-right",
                    autoClose: 1000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    isLoading: false,
                    type: "error",
                    theme: "light",
                    style: {},
                  });
                }
              }}
            >
              Add to featured
            </Button>
          )}

          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              px: { xs: "0.2rem", sm: "0.7rem", md: "0.7rem" },
            }}
          >
            {isFetching ? (
              <Skeleton width={"40%"} component="h2"></Skeleton>
            ) : (
              <Typography
                sx={{ mt: "0.7rem", fontSize: { xs: "0.65rem", sm: "1.2rem" } }}
              >
                {firstName &&
                  `${textFromat(_.upperFirst(firstName))} ${textFromat(
                    _.upperFirst(lastName)
                  )}`}
              </Typography>
            )}
            {isFetching ? (
              <Skeleton
                width="1.5rem"
                height="1.5rem"
                variant="circular"
              ></Skeleton>
            ) : (
              <>
                {flag && (
                  <Box
                    component={"span"}
                    className={`fi fi-${flag?.toLowerCase()}`}
                    style={{
                      fontSize: isNotMobileScreens ? "1.2rem" : "0.85rem",
                    }}
                  ></Box>
                )}
              </>
            )}
          </Box>
          <Box sx={{ width: "100%", mt: "1rem" }}>
            {isFetching ? (
              <Skeleton
                sx={{
                  width: "100%",
                  height: "4rem",
                  mt: "1rem",
                  borderRadius: "0.3rem",
                }}
              ></Skeleton>
            ) : (
              <img
                src={url}
                alt="item-image"
                style={{
                  width: "100%",
                  height: isNotMobileScreens ? "8rem" : "4.5rem",
                  borderRadius: "0.3rem",
                  objectFit: "contain",
                }}
              />
            )}
          </Box>
          {isFetching ? (
            <Skeleton
              variant="rectangular"
              component={"h6"}
              sx={{ mt: "0.5rem" }}
            ></Skeleton>
          ) : (
            <Typography
              sx={{
                mt: "1rem",
                fontSize: { xs: "0.8rem", sm: "1rem", wordBreak: "break-word" },
                px: { xs: "0.2rem", sm: "0.7rem", md: "0.7rem" },
                textAlign: "center",
              }}
            >
              {selling?.slice(0, 19)}
            </Typography>
          )}

          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              mt: { xs: "auto", md: "auto" },
              px: { xs: "0.2rem", sm: "0.7rem", md: "0.7rem" },
            }}
          >
            {isFetching ? (
              <Skeleton
                variant="rectangular"
                component={"h3"}
                sx={{ mt: "0.5rem", width: "40%" }}
              ></Skeleton>
            ) : (
              <Typography
                sx={{
                  fontWeight: "400",
                  fontSize: { xs: "0.55rem", sm: "0.75rem" },
                  color:
                    dayjs().diff(createdAt, "days") > 21 ? "red" : "#0047AB",
                }}
              >
                {createdAt ? dayjs(createdAt).format("DD.MM.YYYY") : ""}
              </Typography>
            )}

            {isFetching ? (
              <Skeleton
                variant="rectangular"
                sx={{ mt: "0.5rem", width: "30%" }}
              ></Skeleton>
            ) : (
              <Typography
                sx={{
                  fontWeight: "600",
                  fontSize: { xs: "0.7rem", sm: "0.75rem" },
                }}
              >
                {`${amount?.toFixed()} ${currency?.toUpperCase()}`}
              </Typography>
            )}
          </Box>
          {cardtype === "Private" && (
            <Box>
              <Button
                sx={{
                  position: "absolute",
                  top: 10,
                  left: 0,
                  display: "inline-flex",
                  backgroundColor: "#0047AB",
                  color: "#F9FAFA",
                  paddingY: "0.1rem",
                  fontSize: "0.7rem",
                }}
                onClick={(e) => {
                  e.stopPropagation();
                  typeof openModal !== "undefined" && openModal();
                  setItemId ? setItemId(id) : "";
                }}
              >
                Edit
              </Button>
              <Button
                sx={{
                  position: "absolute",
                  bottom: 70,
                  left: 0,
                  display: "inline-flex",
                  backgroundColor: "#0047AB",
                  color: "#F9FAFA",
                  paddingY: "0.1rem",
                  fontSize: "0.7rem",
                }}
                onClick={async(e) => {
                  try {
                    e.stopPropagation();
                    // typeof openModal !== "undefined" && openModal();
                    // setItemId ? setItemId(id) : "";
                    const response = await axiosPrivate.put(
                      `seller/update-item/${id}`,
                      {name:""},
                      {
                        headers: { "Content-Type": "multipart/form-data" },
                      }
                      
                    );
                    typeof setRefresh !== "undefined" &&
                      setRefresh((prev: boolean) => !prev);
                  } catch (error) {
                    
                  }
                  
                }}
              >
                Update
              </Button>
              <Button
                sx={{
                  position: "absolute",
                  top: 10,
                  right: 0,
                  display: "inline-flex",
                  backgroundColor: "#0047AB",
                  color: "#F9FAFA",
                  paddingY: "0.1rem",
                  fontSize: "0.7rem",
                }}
                onClick={async (e) => {
                  e.stopPropagation();
                  typeof openDeleteModal !== "undefined" && openDeleteModal()
                  setItemId ? setItemId(id) : "";
                  // await axiosPrivate.delete(`seller/delete-item/${id}`);
                  // typeof setRefresh !== "undefined" &&
                  //   setRefresh((prev: boolean) => !prev);
                }}
              >
                Delete
              </Button>
              {remCollection && (
                <Button
                  sx={{
                    position: "absolute",
                    top: 100,
                    right: 30,
                    display: "inline-flex",
                    backgroundColor: "#0047AB",
                    color: "#F9FAFA",
                    paddingY: "0.1rem",
                    fontSize: "0.7rem",
                  }}
                  onClick={remCollection}
                >
                  remove from Collection
                </Button>
              )}
            </Box>
          )}
        </Box>
      </div>
    </Box>
  );
};

export default ItemsCard;
