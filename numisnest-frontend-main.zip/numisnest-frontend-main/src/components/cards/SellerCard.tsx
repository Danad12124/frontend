import { Box, Typography,Skeleton } from "@mui/material";
import "/node_modules/flag-icons/css/flag-icons.min.css";
import { useNavigate } from "react-router-dom";
import { Fragment } from "react";
import {Person3Outlined} from "@mui/icons-material"
import avater from "src/assets/Image/numisnest avater.jpg";
import Image from "../Image";
import { textFromat } from "src/utilities/constants/helpers";
import approvedicon from "src/assets/Image/AdminIcons/approved.svg";
import notapprovedicon from "src/assets/Image/AdminIcons/cancel.svg";
interface Props {
  flag?: string;
  url?: string;
  name?: string;
  selling?: string;
  isFetching?: boolean;
  id?: string;
  approved?: boolean;
}

const SellerCard = ({ flag, url, name, selling, isFetching,id ,approved}: Props) => {
  const naviagte = useNavigate();
  return (
    <div
      onClick={() => (id ? naviagte(isFetching ? "" : `/seller/${id}`) : "")}
    >
      <Box
        sx={{
          backgroundColor: "white",
          width: {
            xs: "11.5rem",
            sm: "18.1rem",
            md: "18.1rem",
            lg: "18.1rem",
            xl: "21rem",
          },
          height: {
            xs: "17.5rem",
            sm: "21.5rem",
            md: "21.5rem",
            lg: "21.5rem",
            xl: "23.7rem",
          },
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          position: "relative",
          borderRadius: "0.6rem",
          transition: "all 0.3s ease-in-out allow-discrete",
          "&:hover": {
            boxShadow: " 3px 5px 10px 0.7px rgba(0, 0, 0, .2)",
            cursor: "pointer",
          },
        }}
      >
        {isFetching ? (
          <Skeleton
            variant="circular"
            sx={{
              width: "2.5rem",
              height: "2.5rem",
              position: "absolute",
              left: 15,
              top: 10,
            }}
          ></Skeleton>
        ) : (
          <span
            className={`fi fi-${flag?.toLowerCase()}`}
            style={{
              fontSize: "1.7rem",
              position: "absolute",
              left: 15,
              top: 10,
            }}
          ></span>
        )}

        {isFetching ? (
          <Skeleton
            variant="rectangular"
            animation="wave"
            sx={{ width: "12rem", height: "12rem", mt: "2.9rem" }}
          ></Skeleton>
        ) : (
          <Box>
            {url ? (
              <Box
                sx={{
                  width: { xs: "10.5rem", sm: "12rem" },
                  height: { xs: "8.8rem", sm: "12rem" },
                  backgroundImage: `url(${url})`,
                  backgroundSize: "cover",
                  backgroundRepeat: "no-repeat",
                  backgroundPosition: "center",
                  mt: "2.9rem",
                  borderRadius: "0.3rem",
                }}
              ></Box>
            ) : (
              <Image
                src={avater}
                alt="avater"
                sx={{
                  width: { xs: "10.5rem", sm: "12rem" },
                  height: { xs: "8.8rem", sm: "12rem" },
                  mt: "2.9rem",
                }}
              />
            )}
          </Box>
        )}
        {isFetching ? (
          <Fragment>
            <Skeleton
              animation="wave"
              height={30}
              width="80%"
              sx={{ mt: "0.75rem" }}
            />
            <Skeleton
              animation="wave"
              height={30}
              width="80%"
              sx={{ mt: "0.75rem" }}
            />
          </Fragment>
        ) : (
          <Fragment>
            <Box sx={{ display: "flex", alignItems: "center" }}>
              <Typography
                sx={{
                  mt: "",
                  fontSize: { xs: "1.1rem", sm: "1.5rem" },
                  fontWeight: "",
                }}
                fontFamily={"'Noto Sans KR', sans-serif"}
              >
                {textFromat(name)}
              </Typography>
              <Image
                src={approved ? approvedicon : notapprovedicon}
                alt="approved "
                sx={{ width: "1.2rem" }}
              />
            </Box>
            <Typography
              sx={{
                mt: "0.5rem",
                textAlign: "center",
                fontSize: { xs: "0.85rem", sm: "1rem" },
                wordBreak:"break-word"
              }}
            >
              {selling?.slice(0, 40)}
            </Typography>
          </Fragment>
        )}
      </Box>
    </div>
  );
};

export default SellerCard;
