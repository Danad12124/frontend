import React from 'react'
import { AddIcon } from '../Icons/icons';
import { Box, Button, Paper, Typography, useMediaQuery } from '@mui/material';
import { CollectionType } from 'src/utilities/types';
import { dark } from '@mui/material/styles/createPalette';
import Collectionscard from '../cards/collectioncard';
import { EditNoteOutlined } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import LINKS from 'src/utilities/links';

interface Props {
  data?:CollectionType[]|null
  sellerId?:string ;
}

const SellerCollection = ({data,sellerId}:Props) => {
  const navigate  = useNavigate()
  const isNotMobileScreens = useMediaQuery("(min-width:600px)");
  return (
    <Box component={"div"}>
      {data?.[0] ? (
        <Paper
          sx={{
            position: "relative",
            mt: "5rem",
            pl: "2rem",
            pr: "1rem",
            pb: "1rem",
            pt: "2rem",
          }}
        >
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <Typography
              variant={isNotMobileScreens ? "h1" : "h2"}
              sx={{
                fontWeight: 700,
                mr: "2rem",
                mb: "0.5rem",
                color: "#0047AB",
              }}
            >
              Collection
            </Typography>

            <Button
              sx={{
                backgroundColor: "#0047AB",
                color: "white",
                padding: {
                  xs: "0.5rem 2rem",
                  sm: "0.5rem 2.5rem",
                  md: "0.5rem 2.5rem",
                },
                borderRadius: "0.4rem",
              }}
              onClick={() => navigate(LINKS.editCollection)}
            >
              Edit <EditNoteOutlined />
            </Button>
          </Box>
          <Box
            sx={{
              display: "grid",

              gridTemplateColumns: {
                xs: " 1fr",
                sm: "repeat(2, 1fr)",
                md: "repeat(2, 1fr)",
                lg: "repeat(3, 1fr)",
                xl: "repeat(3, 1fr)",
              },
              justifyContent: "center",
              rowGap: "1rem",
              mt: "1.5rem",
            }}
          >
            {data?.slice(0, 3).map((collection, index) => (
              <Box
                component={"div"}
                onClick={() =>
                  navigate(
                    `${LINKS.singleCollectionpublic}/${sellerId}?coll_id=${collection._id}`
                  )
                }
              >
                <Collectionscard
                  key={index}
                  collectionName={collection.name}
                  collectionItems={collection.coll_list}
                />
              </Box>
            ))}
          </Box>
        </Paper>
      ) : (
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            mt: "5rem",
            color: "#0047AB",
          }}
        >
          <Typography
            variant={isNotMobileScreens ? "h1" : "h2"}
            sx={{ fontWeight: 700, mr: "4rem" }}
          >
            Collection
          </Typography>
          <Box>
            <AddIcon
              height={60}
              width={60}
              color="#0047AB"
              onClick={() => navigate(LINKS.createCollection)}
            />
          </Box>
        </Box>
      )}
    </Box>
  );
}

export default SellerCollection