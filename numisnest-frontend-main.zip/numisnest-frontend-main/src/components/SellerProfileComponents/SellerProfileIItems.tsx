import { Box, Button, Paper, Typography, useMediaQuery } from "@mui/material";
import React, { useState } from "react";
import { AddIcon } from "../Icons/icons";
import {
  GroupItems,
  SellerItemType,
  SingleItemType,
} from "src/utilities/types";
import ItemsCard from "../cards/ItemsCard";
import EditItemsModal from "../Modal/edit-ItemsModal";
import { ArrowForwardIosOutlined, ReportProblemRounded, Sledding } from "@mui/icons-material";
import { useNavigate } from "react-router-dom";
import LINKS from "src/utilities/links";
import { dark } from "@mui/material/styles/createPalette";
import ConfirmationModal from "../Modal/are-you-sure";
import { toast } from "react-toastify";
import useAxiosPrivate from "src/hooks/useAxiosPrivate";

interface Props {
  data?: GroupItems[] | null;
  refresh?:boolean,
  setRefresh?:(val :boolean)=>void
}

const SellerProfileIItems = ({ data,refresh ,setRefresh}: Props) => {
  console.log(data)
  const [isDisplayModal, setDisplayModal] = useState<boolean>(false);
  const [displayDeleteModal ,setDisplayDeleteModal] = useState<boolean>(false)
  const [selectedId, setSelectedId] = useState<string | null | undefined>(null);
  console.log(selectedId);
  
  const navigate = useNavigate();
  const isNotMobileScreens = useMediaQuery("(min-width:600px)");
  const axiosPrivate = useAxiosPrivate();
  return (
    <Box component={"div"}>
      {isDisplayModal && (
        <EditItemsModal
          contentWidth={"1200px"}
          closeModal={() => setDisplayModal(false)}
          itemId={selectedId}
          setRefresh={setRefresh}
          refresh= {refresh}
        />
      )}
      {displayDeleteModal && (
        <ConfirmationModal
          contentWidth={"400px"}
          closeModal={() => setDisplayDeleteModal(false)}
          itemId={selectedId}
          text="delete item"
          handleItem={async () => {
            try {
              const response = await axiosPrivate.delete(
                `seller/delete-item/${selectedId}`
              );
              
              toast("Item deleted", {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                isLoading: false,
                type: "success",
                theme: "light",
                style: {},
              });
              typeof setRefresh !== "undefined" && setRefresh(!refresh);
              setDisplayDeleteModal(false)
            } catch (error: any) {
              toast(`${error.response.data.message.split(":")[1]}`, {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                isLoading: false,
                type: "error",
                theme: "light",
                style: {},
              });
            }
          }}
          icon={
            <ReportProblemRounded
              sx={{ color: " #D03531 ", fontSize: "4.5rem" }}
            />
          }
        />
      )}
      {data?.[0] ? (
        <Paper
          sx={{
            position: "relative",
            mt: "5rem",
            pl: "2rem",
            pb: "1rem",
            pt: "2rem",
          }}
        >
          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <Typography
              variant={isNotMobileScreens ? "h1" : "h2"}
              sx={{
                fontWeight: 700,
                mr: "2rem",
                mb: "0.5rem",
              }}
            >
              Items
            </Typography>

            <div onClick={() => navigate(LINKS.allSellerItemsPrivate)}>
              <Typography
                variant={isNotMobileScreens ? "h2" : "h2"}
                sx={{
                  display: "flex",
                  alignItems: "center",
                  color: "#0047AB",
                  mr: "1rem",
                  "&:hover": {
                    cursor: "pointer",
                  },
                }}
              >
                See all{" "}
                <ArrowForwardIosOutlined sx={{ marginLeft: "0.76rem" }} />
              </Typography>
            </div>
          </Box>
          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: {
                xs: " repeat(3, 1fr)",
                sm: "repeat(3, 1fr)",
                md: "repeat(4, 1fr)",
                lg: "repeat(6, 1fr)",
                xl: "repeat(6, 1fr)",
              },
              columnGap: { xs: "0.5rem", lg: "0.9rem", xl: "2rem" },
              rowGap: "2rem",
              justifyItems: "center",
              position: "relative",
              pb: "1rem",
              ml: "-1.9rem",
              mt: "1.5rem",
              transform: "scale(0.94)",
              transformOrigin: "top",
            }}
          >
            {data?.slice(0, 24)?.map((itemm: any, indexx: number) => (
              <Box key={indexx} >
                <ItemsCard
                  key={indexx}
                  url={itemm.photos?.[0].secure_url}
                  currency={itemm.convertedCurrency}
                  selling={itemm.description}
                  createdAt={itemm.updatedAt}
                  amount={itemm.convertedPrice}
                  height="15.5rem"
                  bgColor="#F4F4F6"
                  id={itemm._id}
                  cardtype="Private"
                  openModal={() => setDisplayModal(true)}
                  setItemId={setSelectedId}
                  xsheight="12.5rem"
                  openDeleteModal={()=>setDisplayDeleteModal(true)}
                />
              </Box>
            ))}
          </Box>
          <Box sx={{ display: "flex", justifyContent: "end", mr: "1.5rem" }}>
            <Button
              sx={{
                backgroundColor: "#D03531",
                color: "white",
                padding: "0.5rem 3.8rem",
                borderRadius: "0.4rem",
              }}
              onClick={() => navigate(LINKS.hidden)}
            >
              Hidden
            </Button>
          </Box>
        </Paper>
      ) : (
        <Box sx={{ display: "flex", alignItems: "center", mt: "5rem" }}>
          <Typography
            variant={isNotMobileScreens ? "h1" : "h2"}
            sx={{ fontWeight: 700, mr: "10.5rem" }}
          >
            Items{" "}
          </Typography>
          <Box>
            <AddIcon
              height={60}
              width={60}
              onClick={() => navigate(LINKS.AddItems)}
            />
          </Box>
        </Box>
      )}
    </Box>
  );
};

export default SellerProfileIItems;
