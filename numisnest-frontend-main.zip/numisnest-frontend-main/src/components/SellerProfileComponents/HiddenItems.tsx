import { Box, Typography, useMediaQuery } from "@mui/material";
import React, { useState } from "react";
import { GroupItems } from "src/utilities/types";
import ItemsCard from "../cards/ItemsCard";
import EditItemsModal from "../Modal/edit-ItemsModal";
interface Props {
  data?: GroupItems[];
}
const HiddenItemsComponent = ({ data }: Props) => {
  const [isDisplayModal, setDisplayModal] = useState<boolean>(false);
  const [selectedId, setSelectedId] = useState<string | null | undefined>(null);
  const isNotMobileScreens = useMediaQuery("(min-width:600px)");
  console.log(data)
  return (
    <Box>
      {data?.[0] ? (
        <Box>
          {isDisplayModal && (
            <EditItemsModal
              contentWidth={"1020px"}
              closeModal={() => setDisplayModal(false)}
              itemId={selectedId}
            />
          )}
          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: {
                xs: "repeat(3, 1fr)",
                sm: "repeat(3, 1fr)",
                md: "repeat(4, 1fr)",
                lg: "repeat(6, 1fr)",
                xl: "repeat(6, 1fr)",
              },
              columnGap: { xs: "0.5rem", lg: "0.9rem", xl: "2rem" },
              rowGap: "2rem",
              justifyItems: "center",
              position: "relative",
              pb: "1rem",
              ml: "0rem",
              mt: "1.5rem",
              transform: {
                xs: "scale(0.98)",
                sm: "",
                md: "",
                lg: "scale(0.96)",
              },
            }}
          >
            {data?.slice(0, 6)?.map((item: any, indexx: number) => (
              <Box key={indexx}>
                <ItemsCard
                  key={indexx}
                  url={item?.photos?.[0].secure_url}
                  currency={item.currency}
                  selling={item.description}
                  createdAt={item.updatedAt}
                  amount={item.price}
                  height="15.5rem"
                  bgColor="white"
                  id={item._id}
                  cardtype="Private"
                  openModal={() => setDisplayModal(true)}
                  setItemId={setSelectedId}
                  xsheight="12.5rem"
                />
              </Box>
            ))}
          </Box>
        </Box>
      ) : (
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Typography
            variant={isNotMobileScreens ? "h1" : "h2"}
            sx={{ mt: "5rem" }}
          >
            {" "}
            No Hidden Items
          </Typography>
        </Box>
      )}
    </Box>
  );
};

export default HiddenItemsComponent;
