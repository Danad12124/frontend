import { Box, Button, Paper, Typography, useMediaQuery } from '@mui/material'
import React, { useEffect, useState } from 'react'
import { axiosPublic } from 'src/axios/axios'
import useAxiosPrivate from 'src/hooks/useAxiosPrivate'
import { Spinner } from 'src/pages/Item';
import { SingleSeller, SingleSellerFeaturedItem } from 'src/utilities/types';
import ItemsCard from '../cards/ItemsCard';
import { AddIcon } from '../Icons/icons';
import { EditNoteOutlined } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import LINKS from 'src/utilities/links';
interface Props {
  id ?:string;
}
const SellerFeatured = ({id}:Props) => {
  const navigate = useNavigate()
  const axiosPrivate = useAxiosPrivate()
  const [featured,setFeatured]=useState<SingleSellerFeaturedItem []|null>(null)
    const isNotMobileScreens = useMediaQuery("(min-width:600px)");
  useEffect(()=>{
    const fetchSellerFeatured = async()=>{
      try {
        if(id){
          const response = await axiosPublic.get(`seller/featured/fetch`);
          const { data }: { data: any } = response.data;
          setFeatured(data?.[0].featured_items);
        }else {
          setFeatured(null)
        }
      } catch (error) {
        console.log(error)
      }
    }
    fetchSellerFeatured()
  },[id])
 
  if (!id){
    return (
      <Spinner />
    )
  }
  return (
    <Box>
      {featured?.[0] ? (
        <Paper
          sx={{
            position: "relative",
            mt: "5rem",
            pl: isNotMobileScreens ? "2rem" : "1rem",
            pb: "1rem",
            pt: "2rem",
          }}
        >
          <Box
            sx={{
              display: 'flex',
              alignItems: "center",
              justifyContent: "space-between",
              pr: "1rem",
            }}
          >
            <Typography
              variant={isNotMobileScreens ? "h1" : "h2"}
              sx={{
                fontWeight: 700,
                mr: "2rem",
                mb: "0.5rem",
              }}
            >
              Featured
            </Typography>
            <Button
              sx={{
                backgroundColor: "#0047AB",
                color: "white",
                padding: {
                  xs: "0.5rem 2rem",
                  sm: "0.5rem 2.5rem",
                  md: "0.5rem 2.5rem",
                },
                borderRadius: "0.4rem",
              }}
              onClick={() => navigate(LINKS.featured)}
            >
              Edit  <EditNoteOutlined />
            </Button>
          </Box>

          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: {
                xs: "repeat(3, 1fr)",
                sm: "repeat(3, 1fr)",
                md: "repeat(4, 1fr)",
                lg: "repeat(6, 1fr)",
                xl: "repeat(6, 1fr)",
              },
              justifyItems: "center",
              columnGap: { xs: "0.5rem", lg: "0.9rem", xl: "2rem" },
              rowGap: "2rem",
              ml: "-1.2rem",
              transform: "scale(0.95)",
              pb: "1rem",
            }}
          >
            {featured
              .slice(0, 6)
              .map((item: SingleSellerFeaturedItem, index: number) => (
                <ItemsCard
                  key={index}
                  url={item?.photos?.[0].secure_url}
                  selling={item.name}
                  amount={item.price}
                  currency={"usd"}
                  bgColor="#F4F4F6"
                  height="15.5rem"
                  id={item._id}
                  xsheight="12.5rem"
                />
              ))}
          </Box>
        </Paper>
      ) : (
        <Box sx={{ display: "flex", alignItems: "center", mt: "5rem" }}>
          <Typography sx={{ fontSize: "3rem", fontWeight: 700, mr: "5.5rem" }}>
            Featured{" "}
          </Typography>
          <Box>
            <AddIcon
              height={60}
              width={60}
              onClick={() => navigate(LINKS.featured)}
            />
          </Box>
        </Box>
      )}
    </Box>
  );
}

export default SellerFeatured
