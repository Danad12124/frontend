import { Box, Divider, IconButton, Paper, Typography } from "@mui/material";
import React, { useState } from "react";
import {
    CloseOutlined,
    MoreHorizOutlined,
    ReportProblemRounded,
} from "@mui/icons-material";
import { AnimatePresence, motion } from "framer-motion";
import DOMPurify from "dompurify";
import { useNavigate } from "react-router-dom";
import LINKS from "src/utilities/links";
import { CardType } from "./Adminitemscard";
interface Props {
    title?: string;
    description: string | Node;
    id: string;
    openModal?: () => void;
    setDisplayModal3?: (val: boolean) => void;
    cardtype: CardType;
}
const InfromationCard = ({
    title,
    description,
    id,
    cardtype = "Private",
    setDisplayModal3,
}: Props) => {
    const [showDialog, setShowDialog] = useState<boolean>(false);
    const navigate = useNavigate();
    return (
        <Box
            sx={{
                display: "flex",
                flexDirection: "column",
                bgcolor: "white",
                px: "2rem",
                pb: "1rem",
            }}
        >
            {cardtype === "Private" && (
                <Box sx={{ position: "relative" }}>
                    <IconButton
                        sx={{
                            position: "absolute",
                            right: 5,
                            top: 10,
                        }}
                        onClick={() => setShowDialog(true)}
                    >
                        <MoreHorizOutlined
                            sx={{ fontSize: "2rem", color: "#0047AB" }}
                        />
                    </IconButton>
                    <AnimatePresence>
                        {showDialog && (
                            <Box
                                sx={{
                                    width: "9rem",
                                    height: "8rem",
                                    position: "absolute",
                                    bgcolor: "#F4F4F6",
                                    transformOrigin: "top right",
                                    borderRadius: "0.3rem",
                                    right: 25,
                                    top: 22,
                                }}
                                initial={{ scale: 0 }}
                                animate={{ scale: 1 }}
                                transition={{
                                    when: "beforeChildren",
                                    staggerChildren: 0.2,
                                }}
                                exit={{ scale: 0 }}
                                component={motion.div}
                            >
                                <Box sx={{ position: "relative", display: "" }}>
                                    <IconButton
                                        sx={{
                                            position: "absolute",
                                            right: -5,
                                            top: -5,
                                            color: "#0047AB",
                                        }}
                                        onClick={() => setShowDialog(false)}
                                    >
                                        <CloseOutlined />
                                    </IconButton>
                                </Box>
                                <Box
                                    sx={{
                                        display: "flex",
                                        flexDirection: "column",
                                        alignItems: "center",
                                        gap: "0.5rem",
                                        mt: "1.5rem",
                                    }}
                                >
                                    <Typography
                                        component={motion.div}
                                        sx={{ fontSize: "1rem" }}
                                        initial={{ x: -50, opacity: 0 }}
                                        animate={{ x: 0, opacity: 1 }}
                                        exit={{ x: 50, opacity: 0 }}
                                        onClick={() =>
                                            navigate(
                                                `${LINKS.admininformationtext}?infoid=${id}`
                                            )
                                        }
                                    >
                                        {" "}
                                        Edit
                                    </Typography>
                                    <Divider />
                                    <Typography
                                        component={motion.div}
                                        sx={{ fontSize: "1rem" }}
                                        initial={{ x: -50, opacity: 0 }}
                                        animate={{ x: 0, opacity: 1 }}
                                        exit={{ x: 50, opacity: 0 }}
                                        onClick={() =>
                                            typeof setDisplayModal3 !==
                                                "undefined" &&
                                            setDisplayModal3(true)
                                        }
                                    >
                                        {" "}
                                        Delete
                                    </Typography>
                                </Box>
                            </Box>
                        )}
                    </AnimatePresence>
                </Box>
            )}

            <Paper
                sx={{ mt: "3rem", padding: "0.6rem 2rem", bgcolor: "white" }}
            >
                <Typography
                    variant="h2"
                    sx={{
                        bgcolor: "#0047AB",
                        color: "white",
                        textAlign: "center",
                        py: "0.5rem",
                    }}
                >
                    {" "}
                    {title}
                </Typography>

                <Typography
                    component={"div"}
                    sx={{ ml: "2rem", mt: "2rem" }}
                    dangerouslySetInnerHTML={{
                        __html: DOMPurify.sanitize(description),
                    }}
                />
            </Paper>
        </Box>
    );
};

export default InfromationCard;
