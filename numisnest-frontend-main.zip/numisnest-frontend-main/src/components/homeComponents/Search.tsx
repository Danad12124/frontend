import { SearchOutlined } from "@mui/icons-material";
import _ from "lodash";
import { useCallback } from "react";

interface Props {
  setState?: (value: string) => void;
  handleSearch?: () => void;
}

const Search = ({ setState ,handleSearch}: Props) => {
  //  const debouncedHandleSearch = useCallback(
  //    _.debounce(() => {
  //      handleSearch();
  //    }, 500), // Adjust the debounce delay as needed (e.g., 500 milliseconds)
  //    [handleSearch]
  //  );
    const debouncedSetState = useCallback(
      _.debounce((value: string) => {
        setState && setState(value);
      }, 700), // Adjust the debounce delay as needed (e.g., 300 milliseconds)
      [setState]
    );

  return (
    <div style={{ position: "relative", width: "20rem" }}>
      <input
        className="record-search"
        placeholder="Search"
        onChange={(e) => {
          debouncedSetState(e.target.value);
          handleSearch
        }}
      />
      <SearchOutlined
        className="search"
        sx={{
          fontSize: "1.7rem",
          position: "absolute",
          right: "5%",
          top: "10px",
          color: "#0047AB",
        }}
      />
    </div>
  );
};

export default Search;
