import { Box } from "@mui/material";
import SellersHeader from "../headers/SellersHeader";
import ItemsCard from "../cards/ItemsCard";
import { HomeItemType, ItemType, item } from "src/utilities/types";
import LINKS from "src/utilities/links";
const Items = ({ isFetching, data }: { isFetching?: boolean; data: any }) => {
  console.log(data);
  
  return (
    <SellersHeader titleHead="Items" path={LINKS.Allitems}>
      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: {
            xs: "repeat(3, 1fr)",
            sm: "repeat(3, 1fr)",
            md: "repeat(4, 1fr)",
            lg: "repeat(6, 1fr)",
            xl: "repeat(6, 1fr)",
          },
          columnGap: { xs: "0.5rem", lg: "0.9rem", xl: "2rem" },
          rowGap: "2rem",
          justifyItems: "center",
          position: "relative",
     
          mt: { xs: "2rem", sm: "3rem", md: "5rem" },
         
          
        }}
      >
        {data.slice(0, 48).map((item: HomeItemType, index: number) => (
          <ItemsCard
            key={index}
            flag={item?.item?.iso_code}
            url={item?.item?.photos[0].secure_url}
            firstName={item?.item?.seller_info?.[0].first_name}
            lastName={item?.item?.seller_info?.[0].last_name}
            selling={item?.item?.description}
            createdAt={item?.item?.updatedAt}
            amount={item?.item?.convertedPrice}
            isFetching={isFetching}
            currency={item?.item?.convertedCurrency}
            id={item?.item?._id}
            
          />
        ))}
      </Box>
    </SellersHeader>
  );
};

export default Items;
