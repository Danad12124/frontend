import {
  Box,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  SelectChangeEvent,
  TextField,
  Typography,
  useMediaQuery,
  useTheme,
} from "@mui/material";
import SelectComp from "src/components/Select/SelectComp";
import Search from "src/components/homeComponents/Search";
import { HomeItemType } from "src/utilities/types";
import Pagination from "../Pagination";
import { useEffect, useMemo, useState } from "react";

import ItemsCard from "../cards/ItemsCard";
import { axiosPublic } from "src/axios/axios";
import { countries } from "src/utilities/constants/countries";
import _ from "lodash";
import useAppContext from "src/hooks/useAppContext";
import { CategoryOptions } from "../AddItemsComponents/AddItemsComp";
interface Props {
  data?: any;
  isFetching?: boolean;
  setCountry: (value: string) => void;
  setScountry: (value: string) => void;
  scountry: string;
  setCurrency: (value: string) => void;
  countryValue: string;
  setPage: (value: number) => void;
  setSearchValue: (value: any) => void;
  setSelectedCategories: (value: any) => void;
  selectedCategories: any;
  page: number;
  totalPage: number;
}

const ItemsComponets = ({
  data,
  isFetching,
  setCountry,
  setSelectedCategories,
  selectedCategories,
  setPage,
  setCurrency,
  countryValue,
  totalPage,
  setSearchValue,
  page,
  setScountry,
  scountry,
}: Props) => {
  const theme = useTheme();

  const [availableCountries, setAvailableCountries] = useState<string[]>([]);
  const isNotMobileScreens = useMediaQuery("(min-width:600px)");
  // const CategoryOptions = [
  //   { label: "Banknote", val: "banknote" },
  //   { label: "Coins", val: "coin" },
  //   { label: "Medal", val: "medal" },
  //   { label: "Stamp", val: "stamp" },
  //   { label: "Postcard", val: "postcard" },
  //   { label: "Envelope", val: "envelope" },
  //   { label: "Voucher", val: "voucher" },
  //   { label: "Token", val: "token" },
  //   { label: "Accessories", val: "accessory" },
  //   { label: "Others", val: "other" },
  // ];
  const { state, dispatch } = useAppContext();
  const { availableLocation } = state;
  useEffect(() => {
    const fetchAvailableCountries = async () => {
      try {
        const response = await axiosPublic.get("duo/general/items/countries");
        const { data } = response.data;
        setAvailableCountries(data);
      } catch (error) {
        error;
      }
    };
    fetchAvailableCountries();
  }, []);

  const getCurrencyByCountry = (
    availableCountries: any,
    countriesList: any
  ) => {
    const currencies: any = [];

    availableCountries.forEach((availableCountry: any) => {
      const country = countriesList.find(
        (c: any) => c.name === _.startCase(availableCountry)
      );

      if (country) {
        currencies.push(country.currency);
      }
    });

    return currencies;
  };

  const currencies = useMemo(() => {
    return getCurrencyByCountry(availableCountries, countries);
  }, [availableCountries]);

  const handleChangee = (event: SelectChangeEvent<string[]>) => {
    const value = event.target.value;
    setSelectedCategories(typeof value === "string" ? value.split(",") : value);
  };

  return (
    <Box sx={{ pb: "8rem" }}>
      <Box sx={{ mt: "4rem", display: "flex", justifyContent: "flex-end" }}>
        <SelectComp
          selectLabel="Showing sellers from"
          menuItems={["Everywhere", ...(availableLocation || [])]}
          sx={{ border: "0.79px solid rgba(0, 71, 171, 0.40)" }}
          handleChange={(value) => setCountry(value)}
          value={countryValue}
        />
      </Box>
      <Box sx={{ mt: "1rem" }}>
        <Typography
          variant={isNotMobileScreens ? "h1" : "h2"}
          sx={{ fontWeight: "800", mb: "1rem" }}
        >
          All Items
        </Typography>
        <Box
          sx={{
            display: { sx: "block", sm: "flex" },
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Search setState={setSearchValue} />
          <Box sx={{ display: "flex" }}>
            {/* <SelectComp
              
              selectLabel=""
              menuItems={[
                "banknote",
                "coin",
                "medal",
                "stamp",
                "postcard",
                "envelope",
                "voucher",
                "token",
                "accessories",
                "others",
              ]}
              sx={{
                border: "0.79px solid rgba(0, 71, 171, 0.40)",
                width: "10rem",
                mr: "1.5rem",
                mt: "1.5rem",
              }}
              handleChange={(value) => setCategory(value)}
              value={categoryValue}
            /> */}
            <Select
              multiple
              value={selectedCategories}
              onChange={handleChangee}
              sx={{
                border: "0.79px solid rgba(0, 71, 171, 0.40)",
                width: "8rem",
                height: "2.5rem",
                fontSize: "1.12rem",
                mt: "1.5rem",
                borderRadius: "0.8rem",
              }}
            >
              {CategoryOptions.map((category, index) => (
                <MenuItem key={index} value={category.val}>
                  {category.label}
                </MenuItem>
              ))}
            </Select>
            <SelectComp
              selectLabel=""
              value={scountry}
              menuItems={["Everywhere", ...availableCountries]}
              sx={{
                border: "0.79px solid rgba(0, 71, 171, 0.40)",
                mt: "1.5rem",
              }}
              handleChange={(value) => setScountry(value)}
            />
            <SelectComp
              selectLabel=""
              menuItems={currencies}
              sx={{
                border: "0.79px solid rgba(0, 71, 171, 0.40)",
                mt: "1.5rem",
              }}
              handleChange={(value) => setCurrency(value)}
            />
          </Box>
        </Box>
      </Box>
      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: {
            xs: "repeat(3, 1fr)",
            sm: "repeat(3, 1fr)",
            md: "repeat(4, 1fr)",
            lg: "repeat(6, 1fr)",
            xl: "repeat(6, 1fr)",
          },
          columnGap: {
            xs: "0.3rem",
            sm: "0.4rem",
            md: "0.8rem",
            lg: "0.9rem",
            xl: "2rem",
          },
          rowGap: "2rem",
          justifyItems: "center",
          position: "relative",
          mt: { xs: "2rem", sm: "3rem", md: "5rem" },
        }}
      >
        {data.map((item: HomeItemType, index: number) => (
          <ItemsCard
            key={index}
            flag={item?.item?.iso_code}
            url={item?.item?.photos?.[0].secure_url}
            firstName={item?.item?.seller_info[0].first_name}
            lastName={item?.item?.seller_info[0].last_name}
            selling={item?.item?.description}
            createdAt={item?.item?.updatedAt}
            amount={item?.item?.convertedPrice}
            isFetching={isFetching}
            currency={item?.item?.convertedCurrency}
            id={item?.item?._id}
          />
        ))}
      </Box>

      <Pagination
        sx={{
          display: "flex",
          justifyContent: "center",
          marginTop: "5rem",
          color: theme.palette.primary.light,

          "& .css-c8vooq-MuiButtonBase-root-MuiPaginationItem-root": {
            fontSize: "1.2rem",
            fontFamily: "poppin",
          },
          "& .Mui-selected": {
            backgroundColor: "rgba(0, 71, 171, 0.7)",
            color: "white",
          },
        }}
        size={"large"}
        shape={"circular"}
        variant={"outlined"}
        count={totalPage}
        page={page}
        onChange={(event: any, value: any) => {
          setPage(value);
        }}
      />
    </Box>
  );
};

export default ItemsComponets;
