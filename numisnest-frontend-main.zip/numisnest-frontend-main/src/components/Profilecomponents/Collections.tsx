import { Box, Paper, Typography, useMediaQuery } from '@mui/material'
import { useNavigate } from 'react-router-dom';
import { ArrowForwardIosOutlined } from '@mui/icons-material';
import Collectionscard from '../cards/collectioncard';
import { CollectionType } from 'src/utilities/types';
import LINKS from 'src/utilities/links';
interface Props {
  sellerCollectionData?: CollectionType[];
  sellerId?: string;
  sellerFirstname?:string
}


const Collections = ({sellerCollectionData,sellerId,sellerFirstname}:Props) => {
  const navigate = useNavigate()
  const isNotMobileScreens = useMediaQuery("(min-width:500px)");
  console.log(sellerCollectionData)
  return (
    <Box>
      {sellerCollectionData?.[0] && (
        <Paper
          sx={{ mt: "6rem", pl: "1rem", pt: "2rem", pr: "1rem", pb: "1rem" }}
        >
          <Box
            sx={{
              display: "flex",
              mb: "1.5rem",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <Typography
              variant={isNotMobileScreens ? "h1" : "h3"}
              sx={{ fontWeight: 700 }}
            >
              Collections
            </Typography>
            <div
              onClick={() =>
                navigate(
                  `${LINKS.showColletion}/${sellerId}/${sellerFirstname}`
                )
              }
            >
              <Typography
                variant={isNotMobileScreens ? "h1" : "h3"}
                sx={{
                  display: "flex",
                  alignItems: "center",
                  color: "#0047AB",
                  "&:hover": {
                    cursor: "pointer",
                  },
                }}
              >
                See all{" "}
                <ArrowForwardIosOutlined sx={{ marginLeft: "0.76rem" }} />
              </Typography>
            </div>
          </Box>
          <Box
            sx={{
              display: "grid",

              gridTemplateColumns: {
                xs: " 1fr",
                sm: "repeat(2, 1fr)",
                md: "repeat(2, 1fr)",
                lg: "repeat(3, 1fr)",
                xl: "repeat(3, 1fr)",
              },
              justifyContent: "center",
              rowGap: "1rem",
            }}
          >
            {sellerCollectionData?.slice(0, 3)?.map((collection, index) => (
              <Box
                component={"div"}
                onClick={() =>
                  navigate(
                    `${LINKS.singleCollectionpublic}/${sellerId}?coll_id=${collection._id}`
                  )
                }
              >
                <Collectionscard
                  key={index}
                  collectionName={collection.name}
                  collectionItems={collection.coll_list}
                />
              </Box>
            ))}
          </Box>
        </Paper>
      )}
    </Box>
  );
}

export default Collections