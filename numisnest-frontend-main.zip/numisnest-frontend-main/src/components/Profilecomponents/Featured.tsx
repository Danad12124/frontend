import { Box, Paper, Typography } from '@mui/material';
import { defaultItems } from 'src/utilities/constants';
import { ItemType, SellerProfileType, SingleSeller, SingleSellerFeaturedItem} from 'src/utilities/types';
import ItemsCard from '../cards/ItemsCard';


interface Props {
  data?:any
}

const Featured  = ({data}: Props) => {
  return (
    <Box>
      {data?.featured_items?.[0] && (
        <Paper
          sx={{
            mt: "6rem",
            pl: { xs: "0.5rem", sm: "2rem" },
            pt: { xs: "1.5rem", sm: "2rem" },
          }}
        >
          <Typography sx={{ fontSize: "2rem", fontWeight: 600 }}>
            Featured
          </Typography>
          {data?.featured_items?.[0] ? (
            <Box
              sx={{
                display: "grid",
                gridTemplateColumns: {
                  xs: " repeat(3, 1fr)",
                  sm: "repeat(3, 1fr)",
                  md: "repeat(4, 1fr)",
                  lg: "repeat(6, 1fr)",
                  xl: "repeat(6, 1fr)",
                },
                columnGap: { xs: "0.5rem", lg: "0.9rem", xl: "2rem" },
                rowGap: "2rem",
                transform: {
                  xs: "scale(0.952)",
                  sm: "scale(0.96)",
                  md: "scale(0.96)",
                  lg: "scale(0.96)",
                },
                justifyItems: "center",
                transformOrigin: "top left",
                mt: "2rem",
              }}
            >
              {data?.featured_items
                .slice(0, 6)
                .map((item: SingleSellerFeaturedItem, index: number) => (
                  <ItemsCard
                    key={index}
                    flag={data.iso_code}
                    url={item.photos?.[0].secure_url}
                    firstName={data.first_name}
                    lastName={data.last_name}
                    selling={item.name}
                    amount={item.price}
                    currency={"usd"}
                    bgColor="#F4F4F6"
                    id={item._id}
                    height='15.5rem'
                    xsheight='12.5rem'
                  />
                ))}
            </Box>
          ) : (
            <Box>
              <Typography sx={{ fontSize: "1.4rem", mt: "1rem" }}>
                Seller is yet to add Featured items
              </Typography>
            </Box>
          )}
        </Paper>
      )}
    </Box>
  );
};

export default Featured