import { Box, Paper, Typography, useMediaQuery } from "@mui/material";
import { ItemType, SellerItemType, item } from "src/utilities/types";
import { defaultItems } from "src/utilities/constants";
import ItemsCard from "../cards/ItemsCard";
import { useNavigate } from "react-router-dom";
import { ArrowForwardIosOutlined } from "@mui/icons-material";
import LINKS from "src/utilities/links";

interface Props {
  data?: any;
  sellerId?: string;
}
const ItemsProfile = ({ data, sellerId }: Props) => {
  const navigate = useNavigate();
  const isNotMobileScreens = useMediaQuery("(min-width:600px)");

  return (
    <Box>
      {data?.items?.[0] && (
        <Paper
          sx={{
            mt: "6rem",
            pl: { xs: "0.5rem", sm: "2rem" },
            pt: { xs: "1.5rem", sm: "2rem" },
            pr: "1rem",
            mb: "3rem",
          }}
        >
          <Box
            sx={{
              display: "flex",
              mb: "1.5rem",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <Typography
              variant={isNotMobileScreens ? "h1" : "h3"}
              sx={{ fontWeight: 700 }}
            >
              Items
            </Typography>

            <div
              onClick={() =>
                navigate(`${LINKS.allSellerItemsPublic}/${sellerId}`)
              }
            >
              <Typography
                variant={isNotMobileScreens ? "h1" : "h3"}
                sx={{
                  display: "flex",
                  alignItems: "center",
                  color: "#0047AB",
                  "&:hover": {
                    cursor: "pointer",
                  },
                }}
              >
                See all{" "}
                <ArrowForwardIosOutlined sx={{ marginLeft: "0.76rem" }} />
              </Typography>
            </div>
          </Box>
          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: {
                xs: " repeat(3, 1fr)",
                sm: "repeat(3, 1fr)",
                md: "repeat(4, 1fr)",
                lg: "repeat(6, 1fr)",
                xl: "repeat(6, 1fr)",
              },
              columnGap: { xs: "0.5rem", lg: "0.9rem", xl: "2rem" },
              rowGap: "2rem",
              transform: {
                xs: "scale(0.95)",
                sm: "",
                md: "",
                lg: "scale(0.96)",
              },
              justifyItems: "center",
              transformOrigin: "top left",
              mt: "2rem",
            }}
          >
            {data.items
              ?.slice(0, 24)
              ?.map((item: SellerItemType, index: number) => (
                <ItemsCard
                  key={index}
                  url={item.photos?.[0].secure_url}
                  currency={item.currency}
                  selling={item.description}
                  createdAt={item.updatedAt}
                  amount={item.price}
                  height="15.5rem"
                  bgColor="#F4F4F6"
                  id={item._id}
                  xsheight="12.5rem"
                />
              ))}
          </Box>
        </Paper>
      )}
    </Box>
  );
};

export default ItemsProfile;
