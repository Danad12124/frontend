import {
  Box,
  MenuItem,
  Pagination,
  Select,
  SelectChangeEvent,
  Typography,
  useTheme,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import SelectComp from "../Select/SelectComp";
import Search from "../homeComponents/Search";
import _ from "lodash";
import { GroupItems, SingleItemType } from "src/utilities/types";
import ItemsCard, { CardType } from "../cards/ItemsCard";
import EditItemsModal from "../Modal/edit-ItemsModal";
import { axiosPublic } from "src/axios/axios";
import { CategoryOptions} from "../AddItemsComponents/AddItemsComp";
interface Props {
  sellerName?: string;
  data: any[] | null;
  type?: CardType;
  setCountry?: (value: string) => void;
  countryValue?: string;
  setPage?: (value: number) => void;
  setSearchValue?: (value: any) => void;
  setSelectedCategories?: (value: any) => void;
  selectedCategories?: any;
  page?: number;
  totalPage?: number;
}
const AllSellerItems = ({
  sellerName,
  data,
  type,
  setCountry,
  setPage,
  totalPage,
  page,
  selectedCategories,
  setSelectedCategories,
  setSearchValue,
}: Props) => {
  // const CategoryOptions = [
  //   { label: "Banknote", val: "banknote" },
  //   { label: "Coins", val: "coin" },
  //   { label: "Medal", val: "medal" },
  //   { label: "Stamp", val: "stamp" },
  //   { label: "Postcard", val: "postcard" },
  //   { label: "Envelope", val: "envelope" },
  //   { label: "Voucher", val: "voucher" },
  //   { label: "Token", val: "token" },
  //   { label: "Accessories", val: "accessory" },
  //   { label: "Others", val: "other" },
  // ];
  const theme = useTheme();
  const handleChange = () => {};
  const handleChangee = (event: SelectChangeEvent<string[]>) => {
    const value = event.target.value;
    typeof setSelectedCategories !== "undefined" &&
      setSelectedCategories(
        typeof value === "string" ? value.split(",") : value
      );
  };
  const [isDisplayModal, setDisplayModal] = useState<boolean>(false);
  const [selectedId, setSelectedId] = useState<string | null | undefined>(null);
  const [availableCountries, setAvailableCountries] = useState<string[]>([]);

  useEffect(() => {
    const fetchAvailableCountries = async () => {
      try {
        const response = await axiosPublic.get("duo/general/items/countries");
        const { data } = response.data;
        setAvailableCountries(data);
      } catch (error) {
        error;
      }
    };
    fetchAvailableCountries();
  }, []);
  return (
    <Box>
      {isDisplayModal && (
        <EditItemsModal
          contentWidth={"1200px"}
          closeModal={() => setDisplayModal(false)}
          itemId={selectedId}
        />
      )}
      <Box sx={{ mt: "1rem" }}>
        <Typography
          sx={{
            fontSize: "3.5rem",
            fontWeight: "800",
            mb: "1rem",
            textAlign: "center",
          }}
        >
          {`${_.upperFirst(sellerName)}'s Items`}
        </Typography>
        <Box
          sx={{
            display: { sx: "block", sm: "flex" },
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Search setState={setSearchValue} />
          <Box sx={{ display: "flex" }}>
            <Select
              multiple
              value={selectedCategories}
              onChange={handleChangee}
              sx={{
                border: "0.79px solid rgba(0, 71, 171, 0.40)",
                width: "8rem",
                height: "2.5rem",
                fontSize: "1.12rem",
                mt: "1.5rem",
                borderRadius: "0.8rem",
              }}
            >
              {CategoryOptions.map((category, index) => (
                <MenuItem key={index} value={category.val}>
                  {category.label}
                </MenuItem>
              ))}
            </Select>

            <SelectComp
              selectLabel=""
              menuItems={["Everywhere", ...availableCountries]}
              sx={{
                border: "0.79px solid rgba(0, 71, 171, 0.40)",
                mt: "1.5rem",
              }}
              handleChange={(value) =>
                typeof setCountry !== "undefined" && setCountry(value)
              }
            />
          </Box>
        </Box>

        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: {
              xs: "repeat(3, 1fr)",
              sm: "repeat(3, 1fr)",
              md: "repeat(4, 1fr)",
              lg: "repeat(6, 1fr)",
              xl: "repeat(6, 1fr)",
            },
            columnGap: { xs: "0.5rem", lg: "0.9rem", xl: "2rem" },
            rowGap: "2rem",
            justifyItems: "center",
            position: "relative",
            mt: "5rem",
          }}
        >
          {type === "Private" ? (
            <Box>
              <Box
                sx={{
                  display: "grid",
                  gridTemplateColumns: {
                    xs: "repeat(3, 1fr)",
                    sm: "repeat(3, 1fr)",
                    md: "repeat(4, 1fr)",
                    lg: "repeat(6, 1fr)",
                    xl: "repeat(6, 1fr)",
                  },
                  columnGap: { xs: "0.5rem", lg: "0.9rem", xl: "2rem" },
                  rowGap: "2rem",
                  justifyItems: "center",
                  position: "relative",
                  pb: "1rem",
                  ml: "0rem",
                  mt: "1.5rem",
                  transform: "scale(0.96)",
                }}
              >
                {data?.map((itemm: any, indexx: number) => (
                  <Box key={indexx}>
                    <ItemsCard
                      key={indexx}
                      url={itemm?.photos?.[0].secure_url}
                      currency={itemm.convertedCurrency}
                      selling={itemm.description}
                      createdAt={itemm.updatedAt}
                      amount={itemm.convertedPrice}
                      height="15.5rem"
                      bgColor="#F4F4F6"
                      id={itemm._id}
                      cardtype="Private"
                      openModal={() => setDisplayModal(true)}
                      setItemId={setSelectedId}
                    />
                  </Box>
                ))}
              </Box>{" "}
            </Box>
          ) : (
            <Box
              sx={{
                display: "grid",
                gridTemplateColumns: {
                  xs: "repeat(3, 1fr)",
                  sm: "repeat(3, 1fr)",
                  md: "repeat(4, 1fr)",
                  lg: "repeat(6, 1fr)",
                  xl: "repeat(6, 1fr)",
                },
                columnGap: { xs: "0.3rem", lg: "0.9rem", xl: "2rem" },
                rowGap: "2rem",
                justifyItems: "center",
                position: "relative",
                mt: "3rem",
              }}
            >
              {data?.map((item: SingleItemType, index: number) => (
                <ItemsCard
                  key={index}
                  url={item.photos?.[0].secure_url}
                  selling={item.description}
                  createdAt={item.updatedAt}
                  amount={item.convertedPrice}
                  currency={item.convertedCurrency}
                  height="15.5rem"
                  id={item._id}
                  cardtype={type}
                  openModal={() => setDisplayModal(true)}
                  setItemId={setSelectedId}
                  xsheight="12.5rem"
                />
              ))}{" "}
            </Box>
          )}
        </Box>

        <Pagination
          sx={{
            display: "flex",
            justifyContent: "center",
            marginTop: "5rem",
            color: theme.palette.primary.light,

            "& .css-c8vooq-MuiButtonBase-root-MuiPaginationItem-root": {
              fontSize: "1.2rem",
              fontFamily: "poppin",
            },
            "& .Mui-selected": {
              backgroundColor: "rgba(0, 71, 171, 0.7)",
              color: "white",
            },
          }}
          size={"large"}
          shape={"circular"}
          variant={"outlined"}
          count={totalPage}
          page={page}
          onChange={(event, value) =>
            typeof setPage !== "undefined" && setPage(value)
          }
        />
      </Box>
    </Box>
  );
};

export default AllSellerItems;
